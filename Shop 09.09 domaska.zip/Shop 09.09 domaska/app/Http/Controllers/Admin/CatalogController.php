<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Product;
use App\Price;
use Faker\Factory as Faker;

class CatalogController extends Controller
{
    public function index()
    {
        $page_title = 'Catalog';

        $products = Product::paginate(12);

        return view('admin.catalog', compact('page_title', 'products'));
    }

    public function import()
    {
        $faker = Faker::create('ro_MD');

        $page_title = 'Catalog';

        $products_limit = rand(15, 50);
        for ($p = 1; $p <= $products_limit; $p++) {
            // Product
            $name = $faker->sentence($nbWords = 6, $variableNbWords = true);
            $cover = $faker->unique()->imageUrl($width = 300, $height = 300, 'technics');
            $description = $faker->paragraph($nbSentences = 3, $variableNbSentences = true);

            $images = [];
            $images_limit = rand(2, 5);

            for ($i = 1; $i <= $images_limit; $i++) {
                array_push($images, $faker->unique()->imageUrl($width = 300, $height = 300, 'technics'));
            }

            $images = implode(', ', $images);

            $product = Product::create(compact('name', 'cover', 'images', 'description'));

            // Price
            $value = $faker->randomFloat($nbMaxDecimals = 2, $min = 200, $max = 5000);
            $discount = rand(0, 1);
            $currency_id = 93;

            $price = Price::create(compact('value', 'discount', 'currency_id'));

            // Relations
            $product->prices()->save($price);
        }

        $message = "Successfully generated $products_limit products";

        // return $message;
        return view('admin.catalog', compact('page_title', 'message'));
    }
}
