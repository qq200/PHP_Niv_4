<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Price extends Model
{
    protected $fillable = ['value', 'discount', 'priceable_id' ,'currency_id'];

    public function currency()
    {
        return $this->belongsTo(\App\Currency::class, 'currency_id');
    }

    // public function product() // without polymorphism
    public function priceable()
    {
        // return $this->belongsTo(\App\Product::class); // without polymorphism
        return $this->morphTo(); // with polymorphism
    }
}
