<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = ['name', 'cover', 'images', 'description'];

    public function prices()
    {
        // return $this->hasMany(\App\Price::class); // without polymorphism
        return $this->morphMany(\App\Price::class, 'priceable'); // with polymorphism // priceable prefix (priceable_id / priceable_type)
    }

    public function cartItems()
    {
        return $this->hasMany(\App\CartItem::class);
    }
}
