<?php 
    namespace App;

    class Price {
        private $value;  //daca e privat trebuie prin __set
        private $currency;
        
        public function __construct($value, $currency){
        $this->value= $value;
        $this->currency= $currency;    
        }
        //SETER & GETER (MAGIC!!!)
        public function __set($propr_name, $propr_value){
            print "DADADA";
            if($propr_name=="value" ){
                // print "NUNUNU";
                if(is_integer($propr_value)){
                    $propr_value=trim($propr_value);  //daca de aplica proprietaea name se curata spatiile goale
                }else{
                    die ("ERROR, {$propr_name} must be integer");
                }
            }
            if($propr_name=="currency" ){
                // print "AICI";
                if(strtolower($propr_value)=='eur'|| strtolower($propr_value)=='mdl'|| strtolower($propr_value)=='usd'){
                    print "AICI:ok\n";
                }else{
                    die ("ERROR, {$propr_name} must be EUR or USD or MDL");
                }    
            }
            $this->$propr_name=$propr_value;
        }
        public function __get($propr_name){
            return $this->$propr_name;
        }
    }