{{-- @extends('./public.layout') --}}
@extends('./carts.checkout')

@section('cont-reg')
<form action="/action_page.php">
    <div class="form-group">
      <label for="email">Email address:</label>
      <input type="email" class="form-control" id="email">
    </div>
    <div class="form-group">
        <label for="text">Name</label>
        <input type="text" class="form-control" id="text">
      </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd">
    </div>
    <div class="form-group">
        <label for="pwd">Confirm Password:</label>
        <input type="password" class="form-control" id="pwd">
      </div>
    <div class="checkbox">
      <label><input type="checkbox"> Terms I gree</label>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
</form>
@endsection
