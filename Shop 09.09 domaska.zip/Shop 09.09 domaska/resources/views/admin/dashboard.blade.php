@extends('admin.layout')

@section('content')
    <h5>Hello Admin!</h5>
@endsection
