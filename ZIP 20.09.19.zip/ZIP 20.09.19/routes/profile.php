<?php

// Profile of Client

Route::get('/', function () {
    return 'Profile ok!';
});
