@php
use App\Category;
@endphp

@extends('admin.layout')

@section('import_link')
<a class="nav-link" href="{{ route('admin') }}/categories/import">Generate Categories</a>
@endsection

@isset($message)
@section('message')
<div class="alert alert-success mt-2" role="alert">
    {{ $message }}
</div>
@endsection
@endisset

@isset($categories)
@section('content')
<div class="row">
    <div class="col-md-9">
        <h4>List of categories @if ($total_items > 0)
            <small>({{ $total_items }} items)</small>
            @endif</h4>
    </div>
    <div class="col-md-3">
        @if ($total_items > 10)
        <div class="d-flex justify-content-end">
            <div class="btn-group">
                <button type="button" class="btn btn-sm btn-light dropdown-toggle" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false">
                    {{ $items_per_page}} items on page
                </button>
                <div name="per_page" class="dropdown-menu" aria-labelledby="navbarDropdown">
                    @if ($total_items > 10)
                    <a class="dropdown-item" href="{{ route('admin') }}/categories/?per_page=10">10</a>
                    @endif
                    @if ($total_items > 20)
                    <a class="dropdown-item" href="{{ route('admin') }}/categories/?per_page=25">25</a>
                    @endif
                    @if ($total_items > 40)
                    <a class="dropdown-item" href="{{ route('admin') }}/categories/?per_page=50">50</a>
                    @endif
                    @if ($total_items > 80)
                    <a class="dropdown-item" href="{{ route('admin') }}/categories/?per_page=100">100</a>
                    @endif
                </div>
            </div>
        </div>
        @endif
    </div>
</div>

@if ($total_items > 0)
<div class="row">
    <div class="col-md-12">
        <div class="accordion mb-5" id="accordionExample">
            @foreach ($categories as $category)
            @if ($category->category_id != 0)
            <div class="card">
                <div class="card-header bg-dark" id="headingOne">
                    <h2 class="mb-0">
                        <button class="btn btn-link text-white pl-1" type="button" data-toggle="collapse"
                            data-target="#collapse_id_{{ $category->id }}" aria-expanded="false"
                            aria-controls="collapse_id_{{ $category->id }}">
                            {{ $category->name }}
                        </button>
                    </h2>
                </div>
                <div id="collapse_id_{{ $category->id }}" class="collapse show" aria-labelledby="headingOne"
                    data-parent="#accordionExample">
                    <div class="card-body ml-3">
                        @php
                        $parent_category = Category::find($category->category_id);
                        @endphp
                        {{ $parent_category->name }}
                    </div>
                </div>
            </div>
            @else
            <div class="card">
                <div class="card-header bg-secondary" id="headingOne">
                    <p class="pt-2 pl-1 mb-2 text-white">
                        {{ $category->name }}
                    </p>
                </div>
            </div>
            @endif
            @endforeach
        </div>
    </div>
</div>

@if ($total_items > 10)
{{-- TODO: Custom pagination layout --}}
<div class="d-flex justify-content-center">
    {{ $categories->appends(['per_page' => $items_per_page])->links() }}
</div>
@endif
@else
<p>No items found!</p>
@endif
@endsection
@endisset
