@extends('admin.layout')

@section('import_link')
    <a class="nav-link" href="{{ route('admin.subscribers.import') }}">Generate Subscribers</a>
@endsection

@isset($message)
    @section('message')
        <div class="alert alert-success mt-2" role="alert">
            {{ $message }}
        </div>
    @endsection
@endisset

@isset($emails)
    @section('content')
        <div class="row">
            <div class="col-md-9">
                <h4>List of subscription emails @if ($count_items > 0)
                    <small>({{ $count_items }} items)</small>
                @endif</h4>
            </div>
            <div class="col-md-3">
                @if ($count_items > 10)
                    <div class="d-flex justify-content-end">
                        <div class="btn-group">
                            <button type="button" class="btn btn-sm btn-light dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                {{ $items_per_page}} items on page
                            </button>
                            <div name="per_page" class="dropdown-menu" aria-labelledby="navbarDropdown">
                                @if ($count_items > 10)
                                    <a class="dropdown-item" href="{{ route('admin.subscribers') }}?per_page=10">10</a>
                                @endif
                                @if ($count_items > 10)
                                    <a class="dropdown-item" href="{{ route('admin.subscribers') }}?per_page=25">25</a>
                                @endif
                                @if ($count_items > 25)
                                    <a class="dropdown-item" href="{{ route('admin.subscribers') }}?per_page=50">50</a>
                                @endif
                                @if ($count_items > 50)
                                    <a class="dropdown-item" href="{{ route('admin.subscribers') }}?per_page=100">100</a>
                                @endif
                            </div>
                        </div>
                    </div>
                @endif
            </div>
        </div>

        @if ($count_items > 0)
            <table class="table table-hover mt-3">
            <caption class="text-center">List of subscription emails</caption>
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Email</th>
                        <th scope="col" class="text-right">Created</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($emails as $email)
                        <tr>
                            <th scope="row">{{ $email->id }}</th>
                            <td>{{ $email->email }}</td>
                            <td class="text-right">{{ $email->created_at }}</td>
                        </tr>
                    @endforeach
                </tbody>
                @if ($items_per_page > 25)
                    <tfoot class="bg-light">
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Email</th>
                            <th scope="col" class="text-right">Created</th>
                        </tr>
                    </tfoot>
                @endif
            </table>

            @if ($count_items > 10)
                {{-- TODO: Custom pagination layout --}}
                <div class="d-flex justify-content-center">
                    {{ $emails->appends(['per_page' => $items_per_page])->links() }}
                    {{-- {{ $emails->links() }} --}}
                </div>
            @endif
        @else
            <p>No items found!</p>
        @endif
    @endsection
@endisset
