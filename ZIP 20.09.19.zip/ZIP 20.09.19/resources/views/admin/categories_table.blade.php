@php
    use App\Category;
@endphp

@extends('admin.layout')

@section('import_link')
    <a class="nav-link" href="{{ route('admin') }}/categories/import">Generate Categories</a>
@endsection

@isset($message)
    @section('message')
        <div class="alert alert-success mt-2" role="alert">
            {{ $message }}
        </div>
    @endsection
@endisset

@isset($categories)
    @section('content')
        <div class="row">
            <div class="col-md-9">
                <h4>List of categories @if ($total_items > 0)
                    <small>({{ $total_items }} items)</small>
                @endif</h4>
            </div>
            <div class="col-md-3">
                @if ($total_items > 10)
                    <div class="d-flex justify-content-end">
                        <div class="btn-group">
                            <button type="button" class="btn btn-sm btn-light dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                {{ $items_per_page}} items on page
                            </button>
                            <div name="per_page" class="dropdown-menu" aria-labelledby="navbarDropdown">
                                @if ($total_items > 10)
                                    <a class="dropdown-item" href="{{ route('admin') }}/categories/?per_page=10">10</a>
                                @endif
                                @if ($total_items > 20)
                                    <a class="dropdown-item" href="{{ route('admin') }}/categories/?per_page=25">25</a>
                                @endif
                                @if ($total_items > 40)
                                    <a class="dropdown-item" href="{{ route('admin') }}/categories/?per_page=50">50</a>
                                @endif
                                @if ($total_items > 80)
                                    <a class="dropdown-item" href="{{ route('admin') }}/categories/?per_page=100">100</a>
                                @endif
                            </div>
                        </div>
                    </div>
                @endif
            </div>
        </div>

        @if ($total_items > 0)
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-hover mt-3">
                    <caption class="text-center">List of categories</caption>
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Category</th>
                                <th scope="col">Parent Category</th>
                                {{-- <th scope="col" class="text-right">Created</th> --}}
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($categories as $category)
                                <tr>
                                    <th scope="row">{{ $category->id }}</th>
                                    <td>{{ $category->name }}</td>
                                    @if ($category->category_id != 0)
                                    @php
                                        $parent_category = Category::find($category->category_id);
                                    @endphp
                                        <td>{{ $parent_category->name }}</td>
                                    @else
                                        <td>–</td>
                                        {{-- <td>{{ $category->category_id }}</td> --}}
                                    @endif
                                    {{-- <td>{{ $category->category_id }}</td> --}}
                                    {{-- <td class="text-right">{{ $category->created_at }}</td> --}}
                                </tr>
                            @endforeach
                        </tbody>
                        @if ($items_per_page > 25)
                            <tfoot class="bg-light">
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">category</th>
                                    {{-- <th scope="col" class="text-right">Created</th> --}}
                                </tr>
                            </tfoot>
                        @endif
                    </table>
                </div>
            </div>

            @if ($total_items > 10)
                {{-- TODO: Custom pagination layout --}}
                <div class="d-flex justify-content-center">
                    {{ $categories->appends(['per_page' => $items_per_page])->links() }}
                </div>
            @endif
        @else
            <p>No items found!</p>
        @endif
    @endsection
@endisset
