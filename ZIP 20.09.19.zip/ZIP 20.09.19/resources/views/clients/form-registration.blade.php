{{Auth::id()}}
<form action="{{route('register')}}" method="POST">
    <div class="form-group">
      <label for="email">Email address:</label>
      <input type="email" class="form-control" id="email" name="email">
    </div>
    <div class="form-group">
        <label for="text" >Name</label>
        <input type="text" class="form-control" id="text" name="name">
      </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" name="password">
      @error('password')
      <p>{{$message}}</p>
      @enderror
    </div>
    <div class="form-group">
        <label for="pwd">Confirm Password:</label>
        <input type="password" class="form-control" id="pwd" name="password_confirmation">
      </div>
    <div class="checkbox">
      <label><input type="checkbox"> Terms I gree</label>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
    @csrf
</form>

