<h1> Lista produselor cu poze si preturi</h1>


<hr>
<ol>
@foreach ($products as $product)
    
        <li>
            <h4> {{ $product['p']->name }} </h4>
            <div>
            Pret:{{ $product['p']->price->value }}
            -{{ $product['p']->price->currency }}
            </div>
            @foreach ($product['p']->images as $image)
            
            @foreach($image as $adress)
            
            <img src="{{ $adress['im'] }}" height="100px">
            @endforeach
            
            @endforeach
            
        </li>
       
@endforeach
</ol>

