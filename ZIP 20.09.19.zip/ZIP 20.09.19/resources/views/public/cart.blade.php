@extends('public.layout')

@section('content')

@isset($cart)
<div class="row">
    <div class="col-md-9">
        <h2>Your Cart</h2>
    </div>
</div>

@if ($cart['totalItems'] > 0)
<div class="row">
    <div class="col-md-12">
        <table class="table table-hover mb-5">
            <thead class="bg-dark text-white">
                <tr>
                    <th>#</th>
                    <th>Product</th>
                    <th class="text-center">Quantity</th>
                    <th class="text-center">Price</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                @php
                $i = 1;
                @endphp
                @foreach ($cart['cartItems'] as $item)
                <tr>
                    <td>{{ $i++ }}</td>
                    <td>
                        <img src="{{ $item->product->cover }}" class="rounded" width="40" height="40">
                        <b><a href="{{ route('products') }}/{{ $item->product->id }}"
                                class="text-dark">{{ $item->product->name }}</a></b>
                    </td>
                    <td class="text-center">{{ $item->amount }}</td>
                    <td class="text-center">
                        @if ($item->amount > 1)
                        <b>{{ $item->amount * $item->product->prices->first()->value }}</b>
                        <small>{{ $item->product->prices->where('currency_id', '=', 93)->first()->currency->code }}</small><br>
                        <small><i>{{ $item->amount }} x
                                {{ $item->product->prices->where('currency_id', '=', 93)->first()->value }}
                                {{ $item->product->prices->where('currency_id', '=', 93)->first()->currency->code }}</i></small>
                        @else
                        <b>{{ $item->product->prices->first()->value }}</b>
                        <small>{{ $item->product->prices->where('currency_id', '=', 93)->first()->currency->code }}</small>
                        @endif
                    </td>
                    <td class="text-center">
                        <div class="btn-group">
                            <button type="button" class="btn btn-sm btn-light dropdown-toggle" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">Actions</button>
                            <div name="order_by" class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="{{ route('cart') }}/add_one/{{ $item->id }}"><i
                                        class="fa fa-plus" aria-hidden="true"></i> Add item</a>
                                <a class="dropdown-item" href="{{ route('cart') }}/remove_one/{{ $item->id }}"><i
                                        class="fa fa-minus" aria-hidden="true"></i> Remove item</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item text-danger"
                                    href="{{ route('cart') }}/remove/{{ $item->id }}"><i class="fa fa-trash"
                                        aria-hidden="true"></i> Delete product</a>
                            </div>
                        </div>
                    </td>
                </tr>
                @endforeach
                <tr>
                    <td></td>
                    <td class="text-right"><b>TOTAL:</b></td>
                    <td class="text-center"><b>{{ $cart['totalItems'] }} items</b></td>
                    <td class="text-center"><b>{{ $cart['totalPrice'] }}</b></td>
                    <td class="text-center"><a href="{{ route('cart') }}/empty" class="text-danger"><i
                                class="fa fa-trash" aria-hidden="true"></i>
                            Empty Cart</a></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
@else
Cart is empty.
@endif

@endisset
@endsection
