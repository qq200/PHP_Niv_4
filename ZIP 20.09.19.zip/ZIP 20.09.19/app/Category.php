<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $fillable = ['name', 'category_id'];

    public function parent()
    {
        // return $this->belongsTo(\App\Category::class); // da eroare: nu gaseste parent_id (denumi)
        return $this->belongsTo(\App\Category::class, 'category_id'); // indicam coloana in care se introduce valoare
    }

    public function children()
    {
        return $this->hasMany(\App\Category::class);
    }
}
