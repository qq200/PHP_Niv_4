<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Social extends Model
{
    protected $fillable = ['link'];

    public function contact()
    {
        return $this->belongsTo(\App\ContactData::class);
    }

    public function platform()
    {
        return $this->hasOne(\App\SocialPlatform::class);
    }
}
