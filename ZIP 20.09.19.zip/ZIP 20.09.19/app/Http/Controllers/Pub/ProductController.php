<?php

namespace App\Http\Controllers\Pub;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Currency;

class ProductController extends Controller
{
    public function index()
    {
        // Simple array
        $products = [
            ['name' => 'Product 1', 'price' => 1000],
            ['name' => 'Product 2', 'price' => 2000],
            ['name' => 'Product 3', 'price' => 3000],
        ];

        // Transform array in collection
        $products = collect($products)
            ->sortByDesc('price')
            ->where('price', '>', 1000);

        // dump($products); // var_dump() in symfony
        // dd($products); // dump() and die()

        return view('products/catalog', ['products' => $products]);
    }

    public function test()
    {
        // Metoda 1simpla
        // $c1 = new Currency(); // cream obiect in memorie
        // $c1->name = 'Euro'; // setam valorile
        // $c1->code = 'EUR';

        // $c1->save(); // salvam datele in DB

        // Metoda corecta
        // Currency::create([
        //     'name' => 'US Dollar',
        //     'code' => 'USD'
        // ]);

        $currencies = Currency::all()
            ->sortByDesc('code')
            ->pluck('code');

        dd($currencies);

        return "Ok";
    }
}
