<?php

namespace App\Http\Controllers\Pub;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Product;
use App\Price;
use App\Currency;

class CatalogController extends Controller
{
    public function index()
    {
        $page_title = 'Catalog';

        $products = Product::paginate(12);

        // dd($products);

        // TEST
        // $data = Product::find(1)->prices->first()->currency->code;
        // $data = Currency::find(1)->code;
        // $data = Price::find(1)->currency;
        // $data = Currency::find(93)->code;

        // $data = Product::with('prices')->orderBy('prices.value')->paginate();
        // dd($data);

        return view('public.catalog', compact('page_title', 'products'));
    }

    public function indexPriceSort($sort = 'cheap')
    {
        $page_title = 'Catalog';

        if ($sort == 'cheap') {
            $order_method = 'Asc';
        }
        if ($sort == 'expensive') {
            $order_method = 'Desc';
        }

        $products = Product::join('prices', 'products.id', '=', 'prices.priceable_id')->orderBy('prices.value', $order_method)->paginate(12);

        // dd($products);

        return view('public.catalog', compact('page_title', 'products'));
    }

    public function indexDateSort($sort = 'fresh')
    {
        $page_title = 'Catalog';

        if ($sort == 'fresh') {
            $order_method = 'Asc';
        }
        if ($sort == 'old') {
            $order_method = 'Desc';
        }
        $products = Product::orderBy('created_at', $order_method)->paginate(12);
        // dd($products);

        return view('public.catalog', compact('page_title', 'products'));
    }
}
