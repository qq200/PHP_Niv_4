<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Email;

use Faker\Factory as Faker;

class ClientController extends Controller
{
    public function subscribers(Request $request)
    {
        $page_title = 'Subscribers list';
        $items_per_page = $request->per_page ?? 10;

        // $emails = Email::all();
        $emails = Email::where('subscribed', true)->paginate($items_per_page);

        $count_items = $emails->total();

        return view('admin.subscribers', compact('page_title','emails', 'items_per_page', 'count_items'));
    }

    public function importSubscribers()
    {
        $page_title = 'Subscribers list';
        $faker = Faker::create('ro_MD');

        $emails_count = rand(110, 250);
        for ($i = 1; $i <= $emails_count; $i++) {
            $email = $faker->email;

            $subscribed = rand(0, 1);

            Email::create([
                'email' => $email,
                'subscribed' => $subscribed,
            ]);
        }

        $message = "Successfully generated $emails_count emails";

        // return $message;
        return view('admin.subscribers', compact('page_title', 'message'));
    }

    public function truncateSubcribers()
    {
        Email::truncate();
    }
}
