<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\{Currency, CurrencyRate, Product, Price, City, Client, ContactData, Country, Phone };

class TestController extends Controller
{
    //
    public function run(){
        // $p=Product::create([
        //     'name'=>'Telefon',
        //     'description'=>'Samsung A50 2019 64GB'
        // ]);
        // $pp=Price::create([
        //     'value' =>'EUR',
        //     'discount'=> true
        // ]);
        // $c1=Currency::create([
        //     'name'=> 'Euro',
        //     'cod' =>'EUR'
        // ]);
        // $cr1=CurrencyRate::create([
        //     'rate' => '14.9'
        // ]);
        
        // $p->prices()->save($pp);
        // $pp->currency()->save($c1);
        // $c1->rates()->save($cr1);
        
        // $pf=Product::find(1);
        // // dump($pf);
        // dump($pf->prices->first()->currency->cod);
        $cl1=Client::create([
            'fullname'=> 'Andrei Dimitrovici'            
        ]);
        $cd1=ContactData::create();
        $country=Country::create([
            'name'=>'Moldova',
            'code'=>'MD'
        ]);
        $city=City::create([
            'name'=>'Chisinau',
            'code'=>'2019'
        ]);
        $tel=Phone::create([
            'number'=>'069875125'
        ]);
        $tel2=Phone::create([
            'number'=>'099995125'
        ]);
        $cd1->phones()->save($tel);
        $cd1->phones()->save($tel2);
        $cd1->country()->associate($country);
        $cd1->city()->associate($city);
        $cd1->city()->associate($country);

        $cd1->save();
        $cl1->contact_data()->save($cd1);

        
    }
}
