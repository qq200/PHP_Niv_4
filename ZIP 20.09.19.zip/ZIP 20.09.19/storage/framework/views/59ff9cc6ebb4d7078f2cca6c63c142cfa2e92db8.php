<form action="<?php echo e(route('logout')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <button >Logout</button>

</form><?php /**PATH /opt/lampp/htdocs/shop-v1/resources/views/clients/profile.blade.php ENDPATH**/ ?>