<?php

// Rutele administrative
// Panoul de administrare

Route::get('/', function () {
    return view('admin.dashboard', ['page_title' => 'Admin dashboard']);
})->name('admin');

// Route::prefix('')->group(function () {

// });

// Subscribers
Route::prefix('subscribers')->group(function () {
    Route::get('/', 'ClientController@subscribers');
    Route::post('/', 'ClientController@subscribers')->name('admin.subscribers');
    Route::get('/import', 'ClientController@importSubscribers')->name('admin.subscribers.import');
});


// Currencies
Route::prefix('currencies')->group(function () {
    Route::get('/import', 'CurrencyController@import');
});


// Catalog
Route::prefix('catalog')->group(function () {
    Route::get('/', 'CatalogController@index');
    Route::get('/import', 'CatalogController@import');
});


// Gestionarea Categories
Route::prefix('categories')->group(function () {
    Route::get('/import', 'CategoryController@import');
    Route::resource('/', 'CategoryController');
});

