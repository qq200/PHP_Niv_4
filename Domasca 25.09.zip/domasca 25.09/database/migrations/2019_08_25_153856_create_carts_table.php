<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCartsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('carts', function (Blueprint $table) {
            $table->bigIncrements('id');
            // $table->bigInteger('client_id')->nullable();
            // $table->bigInteger('price_id')->nullable();
            // $table->bigInteger('items_id')->nullable;
            $table->string('status')->default('open');
            $table->timestamps();
            $table->softDeletes(); // ca sa putem utiliza softDeletes
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('carts');
    }
}
