<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RatesHistory extends Model
{
    protected $fillable = ['date', 'rates'];
}
