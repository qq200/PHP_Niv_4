<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Cart extends Model
{
    use SoftDeletes;

    protected $fillable = ['status'];

    public function totalPrices()
    {
        return $this->morphMany(\App\Price::class, 'priceable');
    }

    public function items()
    {
        return $this->hasMany(\App\CartItem::class);
    }
}
