php artisan serve

app-> Clasele noi
app->Http->Controllers-> Controlerele care executa anumite functii in dependenta de cererea venita din ROUTES/WEB.PHP

resource->view-> cum se afiseaza o cerere sau alta pe ecran

routes->web.php arata la ce rura ce comanda se executa

SQLite emuleaza o baza de date ->file.db, 1)configuram conexiunea in .env
2) pregatim baza de date (migration)- un script care indica cum se instaleaza sau dezinstaleaza o structura intr-o baza de date
*) pentru a automatiza acest proces in Laravel utilizam "artisan".
3) CU artizan vom crea  make:migration "create_product_table"
4) migram structura in baza de date : artisan migrate (pentru a intelege caracterele in softwere DB SQLite), se creaza automat migrations Laravel
5) pregatim modelele corespunzatoare (clasa care tine legatura cu baza de date) generam  -tabelul la plural clasa(model) la singular // php artisan make:model Flight


RELATIONS:
Currency->rates(hasMany)->CurrencyRate
Currency<-currency(belongTo)<-CurrencyRate

$c1->rates//get Data (la relatii)
$c1->rates()//get Obiectul relat

php artisan tinker- in consola lucreaza direct cu php

!!!daca e many tu many se permite save($)
daca nu trebue sa fie asociete

Acasa: de adaugat entitatea email, socials
ctrl+p

app-config-app-   provaider- variabilele care trebuie incarcate din start
rutele pentru admin in RUTE SERVICE provaider

dependency injection DI
//////////////////////////////////////////////
Service provaider- diferenta de controller e ca e permanent activ--namespace App\Providers;
Model Cart+relation

1)separate service provider+autoload
    *daca apar erori trebuie php artisan cache:clear
2)boot safie numai pentru web- doar pentru anumite rute
3)session (SessionServiceProvider::class)
4)session<-> Cart <-> current user
5) cream un middle ware pentru a citi cosul din sesiune -CART Middleware


php artisan | grep service
php artisan make:provider CartServiceProvider  - provaider partial

https://github.com/dorinesinenco/EDUQATION/blob/master/web/php/advanced/laravel/collections/shop/README.ro.md#5-relatii-intre-modele-modele-inteligente


https://stripe.com/  vitalie grtai ymail -1q88
https://packagist.org/packages/stripe/stripe-php


Acasa:1)formularul PAYMANT de incadrat in layaut cu bootstrap
2)+ din Json $charge de extras starea (succes sau nu) si de afisat
3)+- daca tranzactia a avut loc cu succes - cosul curent trebuie de setat in statutul achitat(user->hasmany carts) cimpul status de adaugat in cos('paid', la inceput default 'open')
4) de adaugat filtru la bara care afiseaza cosul(cartMidleware) sa se afiseza doar cart open( id in sesiune de resetat); pina sa transmitem cererea din total price transmitem datele, procentul pentru transfer sa se adauge de pe contul clientului

