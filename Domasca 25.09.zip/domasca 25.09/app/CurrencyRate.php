<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CurrencyRate extends Model
{
    protected $fillable = ['currency_id', 'rate'];

    public function currency()
    {
        return $this->belongsTo(\App\Currency::class, );
    }
}
