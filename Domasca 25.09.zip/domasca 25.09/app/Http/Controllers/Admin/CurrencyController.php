<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Http\Traits\FixerEndpoint;
use App\Currency;
use App\CurrencyRate;
use App\RatesHistory;

class CurrencyController extends Controller
{
    use FixerEndpoint;

    public function import($date = 'latest')
    {
        $currencies = $this->getCurrencies()->pluck('id', 'code');

        $rates = $this->getRates($date);

        foreach ($rates as $code => $rate) {
            $currency_id = $currencies[$code];

            $currency_rate = CurrencyRate::updateOrCreate([
                // 'currency_id' => $currency_id,
                'rate' => $rate,
            ]);

            $currency = Currency::find($currency_id);

            $currency->rates()->save($currency_rate);
        }

        return 'All currencies from fixer.io are succesfull imported!';
    }

    private function getRates($date = null)
    {
        $today = date('Y-m-d');

        if ($date == null || $date == 'latest') {
            $date = $today;
        }

        $rates = RatesHistory::where('date', $date)->first();

        if ($rates == null) {
            if ($date == $today || $date == 'latest') {
                $rates = $this->loadRates();
            } else {
                $rates = $this->loadRates($date);
            }
            $this->saveRatesHistory($date, json_encode($rates));

            $rates = collect($rates);
        } else {
            $rates = $rates->get()->pluck('rates');

            $rates = collect(json_decode($rates[0]));
        }

        return $rates;
    }

    private function getCurrencies()
    {
        $currencies = Currency::all();

        if ($currencies->isEmpty()) {
            $currencies = $this->loadCurrencies();
            $currencies = collect($currencies);

            $this->saveCurrencies($currencies);
        }

        return $currencies;
    }

    private function loadRates($date = 'latest')
    {
        $data = $this->getFixerData($date);

        return $data->rates;
    }

    private function loadCurrencies()
    {
        $data = $this->getFixerData('symbols');

        return $data->symbols;
    }

    private function saveRatesHistory($date, $rates)
    {
        RatesHistory::updateOrCreate([
            'date' => $date,
            'rates' => $rates,
        ]);
    }

    private function saveCurrency($code, $name)
    {
        Currency::updateOrCreate([
            'code' => $code,
            'name' => $name,
        ]);
    }

    private function saveCurrencies($currencies)
    {
        foreach ($currencies as $code => $name) {
            $this->saveCurrency($code, $name);
        }
    }
}
