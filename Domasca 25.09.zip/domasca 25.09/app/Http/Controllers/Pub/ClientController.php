<?php

namespace App\Http\Controllers\Pub;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Email;

class ClientController extends Controller
{
    public function subscribeForm()
    {
        return view('public.subscribe');
    }

    public function subscribe(Request $request)
    {
        $email = Email::create([
            'email' => $request->email,
        ]);

        return 'Success subscribe!';
    }
    public function profile()
    {

        return view('clients.profile');
    }
}
