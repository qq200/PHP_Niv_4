<?php

namespace App\Http\Middleware;
use \App\{Cart, Price, Currency};

use Closure;
use Illuminate\Support\Facades\View;

class CartMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // if (isset($cart)) {        
        // if($request->session()->get('cart_id')!=null){
        //     $cart=Cart::find($request->session()->get('cart_id'));
        //     // $request->session()->put('cart_id', $cart->id); 
        //     dump($cart);
        // }else{
        //     $request->session()->put('cart_id', $cart->id);             
        // }
        // // dd($cart);
        // View::share('cart', $cart);
       
        return $next($request);
       
       
       
            //     $price=Price::create(['value'=> 0]);
        //     $price->currency()->associate(Currency::where('code', 'EUR')->first());
        //     $price->save();

        //     $cart->totalPrice()->save($price);
        //     $request->session()->put('cart_id', $cart->id);            
            
        // }
        // else{
        //     $cart=Cart::find($request->session()->get('cart_id'));
            
        // }
        // dump($cart);

        // if ($cart->exists()) {
        //     $cartItems = $cart->items;
        //     // $cartTotalItems = $cart->items->count();

        //     $cartTotalItems = 0;

        //     foreach ($cartItems as $item) {
        //         $cartTotalItems += $item->amount;
        //     }

        //     $cartTotalPrice = $cart->totalPrices->where('currency_id', '=', 93)->first()->value;
        //     $currencyCode = 'MDL';

        //     $cartItems = $cart->items;

        //     // dd($cartItems);

        //     $cartData = [
        //         'totalItems' => $cartTotalItems,
        //         'totalPrice' => $cartTotalPrice,
        //         'currencyCode' => $currencyCode,
        //         'cartItems' => $cartItems
        //     ];
        // }

    }
}
