<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    protected $fillable = ['fullname'];

    public function contacts()
    {
        return $this->hasMany(\App\ContactData::class);
    }
    public function carts()
    {
        return $this->hasMany(\App\Carts::class);
    }
}
