<?php $__env->startSection('content'); ?>
    <h5>Hello Admin!</h5>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\dev\php\php-4\ta_8\shop-v1\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>