<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset('css/stripe.css')); ?>" rel="stylesheet">
    <title>Payment</title>
</head>
<body>
    
<form action="<?php echo e(route('cart.charge')); ?>" method="post" id="payment-form">
        <div class="form-row">
            <label for="card-element">
                Credit or debit card
            </label>
            <div id="card-element">
                <!-- A Stripe Element will be inserted here. -->
            </div>
            
            <!-- Used to display form errors. -->
            <div id="card-errors" role="alert"></div>
        </div>
        
        <button>Submit Payment</button>
        <?php echo csrf_field(); ?>
    </form>
<script src="https://js.stripe.com/v3/"></script>
<script type="text/javascript" src="<?php echo e(asset('js/stripe.js')); ?>"></script>
</body>
</html>



<?php /**PATH /opt/lampp/htdocs/shop-v1/resources/views/carts/payment.blade.php ENDPATH**/ ?>