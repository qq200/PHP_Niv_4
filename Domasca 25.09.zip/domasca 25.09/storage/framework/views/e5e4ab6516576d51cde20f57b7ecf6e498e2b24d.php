<?php
// dd($parentCategories);
?>



<?php $__env->startSection('import_link'); ?>
<a class="nav-link" href="<?php echo e(route('admin')); ?>/categories/import">Generate Categories</a>
<?php $__env->stopSection(); ?>

<?php if(isset($message)): ?>
<?php $__env->startSection('message'); ?>
<div class="alert alert-success mt-2" role="alert">
    <?php echo e($message); ?>

</div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php if(isset($parentCategories)): ?>
<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/shop-v1/resources/views/admin/catalog.blade.php ENDPATH**/ ?>