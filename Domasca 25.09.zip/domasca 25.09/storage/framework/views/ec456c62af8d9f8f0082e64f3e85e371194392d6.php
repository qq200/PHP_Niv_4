<?php if(isset($message)): ?>
<?php $__env->startSection('message'); ?>
<div class="alert alert-success mt-2" role="alert">
    <?php echo e($message); ?>

</div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php if(isset($products)): ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-9">
        <h2>Catalog <small><i><?php echo e($products->total()); ?> products</i></small></h2>
    </div>
    <div class="col-md-3">
        <div class="d-flex justify-content-end">
            <div class="btn-group">
                <button type="button" class="btn btn-sm btn-light dropdown-toggle" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false">
                    Sort By
                </button>
                <div name="order_by" class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="<?php echo e(route('catalog')); ?>/price/expensive">Price Asc (expensive)</a>
                    <a class="dropdown-item" href="<?php echo e(route('catalog')); ?>/price/cheap">Price Desc (cheap)</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo e(route('catalog')); ?>/date/old">Date Asc (old)</a>
                    <a class="dropdown-item" href="<?php echo e(route('catalog')); ?>/date/fresh">Date Desc (fresh)</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 mt-2 mb-3">
        <a href="<?php echo e($product->id); ?>">
            <img src="<?php echo e($product->cover); ?>" class="rounded img-fluid mb-2" alt="<?php echo e($product->name); ?>">
        </a>
        <h5 class="text-center"><a class="text-dark" href="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></a></h5>
        <p class="text-center">
            <b><?php echo e($product->prices->pluck('value')[0]); ?></b> 
            
        </p>
        <p class="text-center">
            <a class="btn btn-sm btn-warning" href="<?php echo e(route('home')); ?>/cart/add/<?php echo e($product->id); ?>">Add to cart</a>
        </p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php if($products->count() > 0): ?>
<div class="d-flex justify-content-center mb-5">
    <?php echo e($products->links()); ?>

</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('public.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop-v1\resources\views/public/catalog.blade.php ENDPATH**/ ?>