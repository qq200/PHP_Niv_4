<?php $__env->startSection('cont-reg'); ?>
<form action="/action_page.php">
    <div class="form-group">
      <label for="email">Email address:</label>
      <input type="email" class="form-control" id="email">
    </div>
    <div class="form-group">
        <label for="text">Name</label>
        <input type="text" class="form-control" id="text">
      </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd">
    </div>
    <div class="form-group">
        <label for="pwd">Confirm Password:</label>
        <input type="password" class="form-control" id="pwd">
      </div>
    <div class="checkbox">
      <label><input type="checkbox"> Terms I gree</label>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('./carts.checkout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop-v1\resources\views////clients/form-registration.blade.php ENDPATH**/ ?>