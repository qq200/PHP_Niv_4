 

<?php $__env->startSection('content'); ?> 
<h1> Lista abonatilor </h1>

    <table class="table">
        
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Email</th>
            <th scope="col">created</th>
            
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row"><?php echo e($list->id); ?></th>
            <td><?php echo e($list->email); ?></td>
            <td><?php echo e($list->created_at); ?></td>           
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
        </tbody>
      </table>
  <?php echo csrf_field(); ?>
 
  <?php echo e($lists->links()); ?>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/shop-v1/resources/views/public/subscribers.blade.php ENDPATH**/ ?>