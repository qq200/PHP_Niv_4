 

<?php $__env->startSection('content'); ?> 
<h1> Lista categoriilor </h1>

  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
            <li><?php echo e($category->name); ?></li>
        
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
 
  <?php echo csrf_field(); ?>
 
  
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/shop-v1/resources/views/admin/categories.blade.php ENDPATH**/ ?>