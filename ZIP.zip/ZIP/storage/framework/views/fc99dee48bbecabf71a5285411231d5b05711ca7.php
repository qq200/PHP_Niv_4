
<h1>Welcome</h1>




<?php /**PATH C:\xampp\htdocs\shop-v1\resources\views/pages/home.blade.php ENDPATH**/ ?>