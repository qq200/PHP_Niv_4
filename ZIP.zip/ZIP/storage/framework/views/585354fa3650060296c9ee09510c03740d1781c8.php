<h1> Lista produselor cu poze si preturi</h1>


<hr>
<ol>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
        <li>
            <h4> <?php echo e($product['p']->name); ?> </h4>
            <div>
            Pret:<?php echo e($product['p']->price->value); ?>

            -<?php echo e($product['p']->price->currency); ?>

            </div>
            <?php $__currentLoopData = $product['p']->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <img src="<?php echo e($adress); ?>" height="100px">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </li>
       
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ol>

<?php /**PATH C:\xampp\htdocs\shop-v1\resources\views/products/test.blade.php ENDPATH**/ ?>