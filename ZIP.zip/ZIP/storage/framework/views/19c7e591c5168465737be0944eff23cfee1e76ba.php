
<h1>Welcome</h1>




<?php /**PATH /opt/lampp/htdocs/shop-v1/resources/views/pages/home.blade.php ENDPATH**/ ?>