<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Currency extends Model
{
    //configuram modelul pe toate componentele
    protected $fillable= ['name', 'cod', 'rate'];
}
