php artisan serve

app-> Clasele noi
app->Http->Controllers-> Controlerele care executa anumite functii in dependenta de cererea venita din ROUTES/WEB.PHP

resource->view-> cum se afiseaza o cerere sau alta pe ecran

routes->web.php arata la ce rura ce comanda se executa

SQLite emuleaza o baza de date ->file.db, 1)configuram conexiunea in .env
2) pregatim baza de date (migration)- un script care indica cum se instaleaza sau dezinstaleaza o structura intr-o baza de date
*) pentru a automatiza acest proces in Laravel utilizam "artisan".
3) CU artizan vom crea  make:migration "create_product_table"
4) migram structura in baza de date : artisan migrate (pentru a intelege caracterele in softwere DB SQLite), se creaza automat migrations Laravel
5) pregatim modelele corespunzatoare (clasa care tine legatura cu baza de date) generam  -tabelul la plural clasa(model) la singular


acasa: 
<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

RELATIONS:
Currency->rates(hasMany)->CurrencyRate
Currency<-currency(belongTo)<-CurrencyRate

$c1->rates//get Data (la relatii)
$c1->rates()//get Obiectul relat

product->preturi>curente>rate
Product::find(1)->prices->first()->currency->code ACASA