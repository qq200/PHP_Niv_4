<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //
    protected $fillable= ['name', 'description'];
    public function prices(){
         return $this->morphMany(\App\Price::class, 'priceable');
    }
    public function images(){
        return $this->hasMany(\App\Image::class);
    }
    public function cartItems()
    {
        return $this->hasMany(\App\CartItem::class);
    }

}
   