<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SocialPlatform extends Model
{
    //
    protected $fillable= ['name', 'nikename'];
    public function contacts(){
        return $this->belongsTo(\App\Client::class);
    }
}
