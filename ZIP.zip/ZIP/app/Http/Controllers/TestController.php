<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\{Currency, CurrencyRate};

class TestController extends Controller
{
    //
    public function run(){
        // $c1=Currency::create([
        //     'cod' =>'EUR',
        //     'name'=> 'Euro'
        // ]);
        // $cr1=CurrencyRate::create([
        //     'rate' => '14.9'
        // ]);
        // $c1=Currency::find(1);
        // dump($c1->rates->sortByDesc('created_at')->first());// sortam dupa inregistrare si luam ultimul
        dump($c1->rates());
        // $c1->rates()->save($cr1);
    }
}
