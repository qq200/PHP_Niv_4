<?php

namespace App\Http\Controllers\Pub;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\{Currency, CurrencyRate, Product, Price, City, Client, ContactData, Country, Phone, Category, Cart, CartItem};
use Illuminate\Support\Facades\DB;

class CartController extends Controller
{
    
    public function add($product_id){ 
        
        $item=CartItem::create([
            'amount' => 1
        ]);
        $prod=Product::all();
        $cartt=Cart::create();
      
        foreach ($prod as $val){
          
          if($val->id==$product_id){
            $item->product()->save($val);
            $val->cartItems()->save($item);
            $item->cart()->save($cartt);
            // if(isset($val->prices)){

            //   $tp=$val->prices->first();
            //   $cartt->totalPrice()->save($tp);
            // }            
          }
        }        
        $sum_item= $prod->where('id',$product_id )->first()->cartItems->sum('amount') ; //cantitatea de produse de acelasi fel
        $sum_total= ($prod->where('id',$product_id)->first()->prices->first()->value) * $sum_item;// suma preturilor produselor de acelasi fel


          return view('public.layout', ['item'=> $item, 'prod'=>$prod,  'sum_total'=>$sum_total, 'sum_item'=> $sum_item]);
        }
}
