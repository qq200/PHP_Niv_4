<?php

namespace App\Http\Controllers\Pub;



use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\{Currency, CurrencyRate, Product, Price, City, Client, ContactData, Country, Phone, Category};

class TestController extends Controller
{
    //
    public function run(){
        Category::truncate(); //stergerea datelor
        $p=Product::create([
            'name'=>'Telefon m3',
            'description'=>'Samsung A30 2019 64GB'
        ]);
        $pp=Price::create([
            'value' =>'900',
            'discount'=> true
        ]);
        $c1=Currency::create([
            'name'=> 'Euro',
            'cod' =>'EUR'
        ]);
        $cr1=CurrencyRate::create([
            'rate' => '14.9'
        ]);
            $po=Product::create([
                'name'=>'Telefon model 4',
                'description'=>'Samsung A80 2019 124GB'
            ]);
            $ppo=Price::create([
                'value' =>'1900',
                'discount'=> true
            ]);
            $c1o=Currency::create([
                'name'=> 'Euro',
                'cod' =>'EUR'
            ]);
            $cr1o=CurrencyRate::create([
                'rate' => '14.9'
            ]);
        
        $p->prices()->save($pp);
        $pp->product()->associate($p);
        $pp->currency()->save($c1);
        $pp->save();
        $c1->price()->save($pp);
        $c1->rates()->save($cr1);

        $po->prices()->save($ppo);
        $ppo->product()->associate($po);
        $ppo->currency()->save($c1o);
        $ppo->save();
        $c1o->price()->save($ppo);
        $c1o->rates()->save($cr1o);
        
        // $pf=Product::find(1);
        // // dump($pf);
        // dump($pf->prices->first()->currency->cod);
                // $cl1=Client::create([
                //     'fullname'=> 'Andrei Dimitrovici'            
                // ]);
                // $cd1=ContactData::create();
                // $country=Country::create([
                //     'name'=>'Moldova',
                //     'code'=>'MD'
                // ]);
                // $city=City::create([
                //     'name'=>'Chisinau',
                //     'code'=>'2019'
                // ]);
                // $tel=Phone::create([
                //     'number'=>'069875125'
                // ]);
                // $tel2=Phone::create([
                //     'number'=>'099995125'
                // ]);
                // $sp1=SocialPlatform::create([
                //     'name'=>'vasiok',
                //     'nikename'=>'vasea2019'
                // ]);
                // $em=Email::create([
                //     'email'=>'vasea@mail.ru'
                // ]);
                // $cd1->phones()->save($tel);
                // $cd1->phones()->save($tel2);
                // $cd1->country()->associate($country);
                // $cd1->city()->associate($city);
                // $cd1->city()->associate($country);

                // $cd1->save();
                // $cl1->contact_data()->save($cd1);
        // Category::truncate(); //stergerea datelor
        // $ca=Category::create([
        //     'name'=> 'Papeterie'
        // ]);
        // $ca2=Category::create([
        //     'name'=> 'Agende'
        // ]);
        // $ca31=Category::create([
        //     'name'=> 'Culoare Neagra' // popcorn sarat
        // ]);
        // $ca32=Category::create([
        //     'name'=> 'Culoare Verde' // popcorn sarat
        // ]);

        // $ca->cildren()->save($ca2);
        // $ca31->parent()->associate($ca2);
        // $ca31->save();
        // $ca32->parent()->associate($ca2);
        // $ca32->save();

        // $ca2a=Category::create([
        //     'name'=> 'Stikere'
        // ]);
        // $ca31a=Category::create([
        //     'name'=> 'Galbene' // popcorn sarat
        // ]);
        // $ca32a=Category::create([
        //     'name'=> 'Rosii' // popcorn sarat
        // ]);
        // $ca->cildren()->save($ca2a);
        // $ca31a->parent()->associate($ca2a);
        // $ca31a->save();
        // $ca32a->parent()->associate($ca2a);
        // $ca32a->save();

        // $caq=Category::create([
        //     'name'=> 'Rechizite'
        // ]);
        // $ca2q=Category::create([
        //     'name'=> 'Pixuri'
        // ]);
        // $ca31q=Category::create([
        //     'name'=> 'Culoare Albastra' // popcorn sarat
        // ]);
        // $ca32q=Category::create([
        //     'name'=> 'Culoare Rosie' // popcorn sarat
        // ]);

        // $caq->cildren()->save($ca2q);
        // $ca31q->parent()->associate($ca2q);
        // $ca31q->save();
        // $ca32q->parent()->associate($ca2q);
        // $ca32q->save();

        // $caqq=Category::create([
        //     'name'=> 'Electronice'
        // ]);
        // $ca2qq=Category::create([
        //     'name'=> 'Calculator de masa'
        // ]);
        // $ca31qq=Category::create([
        //     'name'=> 'Marimea S' // popcorn sarat
        // ]);
        // $ca32qq=Category::create([
        //     'name'=> 'Marimea M' // popcorn sarat
        // ]);

        // $caqq->cildren()->save($ca2qq);
        // $ca31qq->parent()->associate($ca2qq);
        // $ca31qq->save();
        // $ca32qq->parent()->associate($ca2qq);
        // $ca32qq->save();

        // $result=Category::where('name', 'Rechizite')->get();
        // dd($result->first()->cildren);
    }
}
