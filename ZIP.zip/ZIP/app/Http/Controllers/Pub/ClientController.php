<?php

namespace App\Http\Controllers\Pub;
use App\Email;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;


class ClientController extends Controller
{
    ///
    public function subscribeForm(){
        return view('public.subscribe');
    }
    public function subscribe(Request $request){ // in loc de $_POST
        Email::create([
            'email'=>$request->email
        ]);

        // dump($request->email);
        // return 'YOU HAVE BEEN SUBSCRIBE'; //CSRF 419 eroare nu este om
    }
}
