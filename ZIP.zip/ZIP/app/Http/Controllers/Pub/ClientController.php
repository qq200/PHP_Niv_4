<?php

namespace App\Http\Controllers\Pub;
use App\Email;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;


class ClientController extends Controller
{
    ///
    public function subscribeForm(){
        return view('public.subscribe');
    }
    public function subscribe(Request $request){ // in loc de $_POST
        Email::create([
            'email'=>$request->email
        ]);
        // dump($request->email);
        // return 'YOU HAVE BEEN SUBSCRIBE'; //CSRF 419 eroare nu este om
    }

    public function subscribers(Request $request){ // in loc de $_POST
    //    $lists=Email::all();
    $lists = DB::table('emails')->paginate(3); //citi pe pagina sa apara
    //    $lists=Email->simplePaginate(8);

    //    return view('public.subscribers', ['emails' => $emails]);
    //    return $lists;
    //    return view('public.subscribers');
       return view('public.subscribers', ['lists' => $lists]);
    }
}
