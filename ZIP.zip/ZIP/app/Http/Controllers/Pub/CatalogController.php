<?php

namespace App\Http\Controllers\Pub;

use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use App\{Currency, CurrencyRate, Product, Price, City, Client, ContactData, Country, Phone, Category, Cart, CartItem};
use Illuminate\Support\Facades\DB;

class CatalogController extends Controller{

    
    //
    public function index(){
        $products = Product::paginate(12);
        
        return view('public.products_catalog', ['products' => $products]);
    }
    public function indexPriceSort($sort){
        
        if($sort=='expensive'){
            $products = Product::join('prices', 'products.id', '=', 'prices.priceable_id')->orderBy('prices->value', 'desc')->paginate(12);//????????????????
        }
        if($sort=='cheap'){
            $products = Product::join('prices', 'products.id', '=', 'prices.priceable_id')->orderBy('prices->value', 'asc')->paginate(12);//?????????????????????
        }

        return view('public.products_catalog', ['products' => $products]);
    }
    public function indexDateSort($sort){
        if($sort=='old'){
            $products =Product::orderBy('created_at', 'desc')->paginate(12);
        }
        if($sort=='fresh'){
            $products =Product::orderBy('created_at', 'asc')->paginate(12);
        }
        
        return view('public.products_catalog', ['products' => $products]);
    }
}
