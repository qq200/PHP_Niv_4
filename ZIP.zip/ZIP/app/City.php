<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class City extends Model

{
    protected $fillable= ['name', 'code'];
    //apartineo tarii
    public function country(){
        return $this->belongsTo(\App\Country::class);// din model ///apartine
    }
    public function contacts(){//mai multe contacte cu s la urma
        return $this->hasMany(\App\Country::class);// din model
    }

}
