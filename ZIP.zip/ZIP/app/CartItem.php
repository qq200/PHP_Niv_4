<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class CartItem extends Model
{
    use SoftDeletes;
    protected $fillable= ['amount'];
    public function itemPrice(){
         return $this->morphMany(\App\Price::class, 'priceable');
    }
    public function cart()
    {
        return $this->hasOne(\App\Cart::class);
    }
    public function product(){
        return $this->hasOne(\App\Product::class);//+

   }
}
