<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Price extends Model
{
    //
    protected $fillable= ['value', 'discount'];
    public function currency()
    {
        return $this->hasOne(\App\Currency::class);
    }
    public function product()
    {
        return $this->belongTo(\App\Product::class);
    }
}
