<?php

//rutele 

Route::get('/', function () {
    return 'profile ok';
});
?>