<?php

//rutele administarative

Route::get('/', function () {
    return view('admin.dashboard');
});

Route::get('/test', function () {
    return 'TEST NORMAL';
});
?>