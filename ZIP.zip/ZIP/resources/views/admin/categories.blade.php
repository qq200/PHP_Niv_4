@extends ('admin.layout') 
{{-- trebuie de extins --}}
@section('content') 
                                {{-- <h1> Lista categoriilor </h1>

                                  @foreach ($categories as $category)
                                          
                                            {{-- <li>{{ $category->name }}</li> --}}
                                            {{-- <li>{{ $category->name }}</li>

                                            @endforeach           
                                        
                                          <p>{{ $subcategories-> }}</p> --}}
   @foreach($categories as $category)
 
  @if($category->category_id!=NULL) 
      <!-- дети-->
       <div class="panel panel-default" >
         @if($category->parent->category_id==NULL)     
          <div class="panel-heading" style="background-color:lightblue" >
              <h4 class="panel-title" >
                  <a data-toggle="collapse" data-parent="#accordian" href="#womens" >
                      <span class="badge pull-right" ><i class="fa fa-plus"></i>  </span> 
                      {{ $category->name}}
                    </a>
                  </h4>
                </div>
                @else
            <div id="womens" class="panel-collapse collapse">
              <div class="panel-body">
                <ul>
                  <li>
                      <a data-toggle="collapse" data-parent="#accordian" href="#">{{ $category->name}}</a>
                      
                  </li>
                </ul>
              </div>
            </div>
            </div>
            @endif
      @endif
      @if($category->category_id==NULL)
      <!-- родительские-->
      <div class="panel panel-default" >
        <div class="panel-heading" style="background-color:blue">
          <h4 class="panel-title"><a href="#">{{ $category->name}} </a></h4>
        </div>
      </div>
      @csrf
      
      @endif

      @endforeach
      
      @endsection