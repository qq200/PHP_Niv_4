@extends ('admin.layout') 
{{-- trebuie de extins --}}
@section('content') 
<h1> Lista categoriilor </h1>

  @foreach ($categories as $category)
          
            <li>{{ $category->name }}</li>
        
          
          @endforeach           
 
  @csrf
 
  {{-- {{ $categorys->links() }} --}}
  @endsection