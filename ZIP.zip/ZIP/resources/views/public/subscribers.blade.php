@extends ('public.layout') 
{{-- trebuie de extins --}}
@section('content') 
<h1> Lista abonatilor </h1>

    <table class="table">
        
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Email</th>
            <th scope="col">created</th>
            
          </tr>
        </thead>
        <tbody>
          @foreach ($lists as $list)
          <tr>
            <th scope="row">{{ $list->id }}</th>
            <td>{{ $list->email }}</td>
            <td>{{ $list->created_at }}</td>           
          </tr>
          @endforeach           
        </tbody>
      </table>
  @csrf
 
  {{ $lists->links() }}
  @endsection