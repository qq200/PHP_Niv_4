 

<?php $__env->startSection('content'); ?> 
                                
                                            
   <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 
  <?php if($category->category_id!=NULL): ?> 
      <!-- дети-->
       <div class="panel panel-default" >
         <?php if($category->parent->category_id==NULL): ?>     
          <div class="panel-heading" style="background-color:lightblue" >
              <h4 class="panel-title" >
                  <a data-toggle="collapse" data-parent="#accordian" href="#womens" >
                      <span class="badge pull-right" ><i class="fa fa-plus"></i>  </span> 
                      <?php echo e($category->name); ?>

                    </a>
                  </h4>
                </div>
                <?php else: ?>
            <div id="womens" class="panel-collapse collapse">
              <div class="panel-body">
                <ul>
                  <li>
                      <a data-toggle="collapse" data-parent="#accordian" href="#"><?php echo e($category->name); ?></a>
                      
                  </li>
                </ul>
              </div>
            </div>
            </div>
            <?php endif; ?>
      <?php endif; ?>
      <?php if($category->category_id==NULL): ?>
      <!-- родительские-->
      <div class="panel panel-default" >
        <div class="panel-heading" style="background-color:blue">
          <h4 class="panel-title"><a href="#"><?php echo e($category->name); ?> </a></h4>
        </div>
      </div>
      <?php echo csrf_field(); ?>
      
      <?php endif; ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop-v1\resources\views/admin/categories.blade.php ENDPATH**/ ?>