 

<?php $__env->startSection('content'); ?> 

<h1> Afisarea produselor </h1>
<p style="text-align:right"><a href="/catalog/date/old">Sort of old date</a></p>
<p style="text-align:right"><a href="/catalog/date/fresh">Sort of fresh date</a></p>
    <table class="table">
        
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Product</th>
            <th scope="col">Price</th>
            <th scope="col">Created</th>
            
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row"><?php echo e($product->id); ?></th>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->prices->first()->value); ?></td>
            <td><?php echo e($product->created_at); ?></td>           
          </tr>
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
        </tbody>
      </table>
  <?php echo csrf_field(); ?>
 
  <?php echo e($products->links()); ?>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop-v1\resources\views/public/products_catalog.blade.php ENDPATH**/ ?>