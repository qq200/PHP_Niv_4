<?php $__env->startSection('import_link'); ?>
    <a class="nav-link" href="<?php echo e(route('admin.subscribers.import')); ?>">Generate Subscribers</a>
<?php $__env->stopSection(); ?>

<?php if(isset($message)): ?>
    <?php $__env->startSection('message'); ?>
        <div class="alert alert-success mt-2" role="alert">
            <?php echo e($message); ?>

        </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php if(isset($emails)): ?>
    <?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-9">
                <h4>List of subscription emails <?php if($count_items > 0): ?>
                    <small>(<?php echo e($count_items); ?> items)</small>
                <?php endif; ?></h4>
            </div>
            <div class="col-md-3">
                <?php if($count_items > 10): ?>
                    <div class="d-flex justify-content-end">
                        <div class="btn-group">
                            <button type="button" class="btn btn-sm btn-light dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php echo e($items_per_page); ?> items on page
                            </button>
                            <div name="per_page" class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <?php if($count_items > 10): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('admin.subscribers')); ?>?per_page=10">10</a>
                                <?php endif; ?>
                                <?php if($count_items > 10): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('admin.subscribers')); ?>?per_page=25">25</a>
                                <?php endif; ?>
                                <?php if($count_items > 25): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('admin.subscribers')); ?>?per_page=50">50</a>
                                <?php endif; ?>
                                <?php if($count_items > 50): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('admin.subscribers')); ?>?per_page=100">100</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <?php if($count_items > 0): ?>
            <table class="table table-hover mt-3">
            <caption class="text-center">List of subscription emails</caption>
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Email</th>
                        <th scope="col" class="text-right">Created</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($email->id); ?></th>
                            <td><?php echo e($email->email); ?></td>
                            <td class="text-right"><?php echo e($email->created_at); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <?php if($items_per_page > 25): ?>
                    <tfoot class="bg-light">
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Email</th>
                            <th scope="col" class="text-right">Created</th>
                        </tr>
                    </tfoot>
                <?php endif; ?>
            </table>

            <?php if($count_items > 10): ?>
                
                <div class="d-flex justify-content-center">
                    <?php echo e($emails->appends(['per_page' => $items_per_page])->links()); ?>

                    
                </div>
            <?php endif; ?>
        <?php else: ?>
            <p>No items found!</p>
        <?php endif; ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\dev\php\php-4\ta_8\shop-v1\resources\views/admin/subscribers.blade.php ENDPATH**/ ?>