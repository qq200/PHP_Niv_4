<?php

namespace App\Http\Controllers\Pub;
use Artisan;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller\Pub;
use App\{Currency, CurrencyRate, Product, Price, City, Client, ContactData, Country, Phone, Category, Cart};

class CatalogController extends Controller
{
    //
    public function index(){
        $catalogs = DB::table('products')->paginate(12); //citi pe pagina sa apara

       return view('public.products_catalog', ['catalogs' => $catalogs]);

    }
}