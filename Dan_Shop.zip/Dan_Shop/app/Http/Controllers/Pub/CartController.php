<?php

namespace App\Http\Controllers\Pub;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Cart;
use App\CartItem;
use App\Price;
use App\Product;

class CartController extends Controller
{
    public function view()
    {
        $page_title = 'Cart';
        return view('public.cart', compact('page_title'));
    }

    public function add($product_id)
    {
        $cart = Cart::first();

        if (!isset($cart)) {
            $cart = Cart::create();
        }

        // dd(!$cart->items->where('product_id', $product_id)->isEmpty());

        if (($cart->items->count() > 0) && !$cart->items->where('product_id', $product_id)->isEmpty()) {
            $productAmount = $cart->items->where('product_id', '=', $product_id)->first()->amount;
            $productAmount += 1;
            $cart->items->where('product_id', '=', $product_id)->first()->update(['amount' => $productAmount]);
        } else {
            $product = Product::find($product_id);

            $cartItem = CartItem::create();
            $cartItem->product()->associate($product)->save();
            $cartItem->cart()->associate($cart)->save();

            // Price
            $product_price = $product->prices->where('currency_id', '=', 93)->first();
            $value = $product_price->value;
            $discount = $product_price->discount;
            $currency_id = $product_price->currency_id;

            $itemPrice = Price::create(compact('value', 'discount', 'currency_id'));

            $cartItem->itemPrices()->save($itemPrice);
        }


        $this->updateCartTotalPrice();

        return redirect()->route('catalog');
    }

    public function updateCartTotalPrice()
    {
        $cart = Cart::first();

        $totalPrice = 0;

        // dd($items);

        foreach ($cart->items as $item) {
            $totalPrice += $item->itemPrices->where('currency_id', 93)->first()->value * $item->amount;
        }

        // dd($totalPrice);

        if ($cart->totalPrices->isEmpty()) {
            $value = 0;
            $currency_id = 93;
            $totalPrice = Price::create(compact('value', 'currency_id'));
            $cart->totalPrices()->save($totalPrice);
        };

        $cart->totalPrices->where('currency_id', 93)->first()->update(['value' => $totalPrice]);
    }

    public function remove($item_id)
    {
        $cart = Cart::first();

        $cart->items->find($item_id)->delete();

        $this->updateCartTotalPrice($cart);

        return redirect()->route('cart.view');
    }

    public function add_one($item_id)
    {
        $cart = Cart::first();

        // dd($cart->items->where('id', $item_id));

        $productAmount = $cart->items->find($item_id)->amount;

        $productAmount += 1;
        $cart->items->find($item_id)->update(['amount' => $productAmount]);
        $this->updateCartTotalPrice($cart);

        return redirect()->route('cart.view');
    }

    public function remove_one($item_id)
    {
        $cart = Cart::first();

        $productAmount = $cart->items->find($item_id)->amount;

        if ($productAmount <= 1) {
            $this->remove($item_id);
        } else {
            $productAmount -= 1;
            $cart->items->find($item_id)->update(['amount' => $productAmount]);
            $this->updateCartTotalPrice($cart);
        }

        return redirect()->route('cart.view');
    }

    public function empty()
    {
        $cart = Cart::first();

        foreach ($cart->items as $item) {
            $item->delete();
        }

        $this->updateCartTotalPrice($cart);

        return redirect()->route('cart.view');
    }
}
