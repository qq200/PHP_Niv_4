<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Category;

use Faker\Factory as Faker;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $page_title = 'Categories list';

        $items_per_page = $request->per_page ?? 10;

        // $categories = Category::orderBy('name')->paginate($items_per_page);
        // $categories = Category::paginate($items_per_page);
        // $count_items = $categories->total();
        $count_items = Category::paginate($items_per_page)->total();
        $parentCategories = Category::whereNull('category_id')->orderBy('name')->paginate($items_per_page);
        $count_parentCategories = $parentCategories->total();
        // $subcategories = Category::whereNotNull('category_id');
        $count_subcategories = Category::whereNotNull('category_id')->count();

        // return 'Ok';
        // return view('admin.categories', compact('page_title', 'categories', 'parentCategories', 'subcategories', 'items_per_page', 'count_items', 'count_parentCategories', 'count_subcategories'));
        return view('admin.categories', compact('page_title', 'parentCategories', 'items_per_page', 'count_items', 'count_parentCategories', 'count_subcategories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function import()
    {
        $page_title = 'Categories list';

        Category::truncate();

        $faker = Faker::create();
        $faker->addProvider(new \Bezhanov\Faker\Provider\Commerce($faker));

        $categories_count = rand(50, 100);
        for ($i = 1; $i <= $categories_count; $i++) {
            do {
                $name = $faker->department();
            } while (Category::where('name', '=', $name)->exists());

            $count_parentCategories = Category::where('category_id', '=', null)->count();

            $category_level = rand(0, 1);

            if ($category_level == 0) {
                $category_id = null;
            } else {
                $category_id = rand(1, $count_parentCategories);
            }

            Category::create(compact('name', 'category_id'));
        }

        $message = "Successfully generated $categories_count categories";

        // return $message;
        return view('admin.categories', compact('page_title', 'message'));
    }

    public function truncate()
    {
        Category::truncate();
    }
}
