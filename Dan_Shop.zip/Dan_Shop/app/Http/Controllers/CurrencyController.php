<?php

namespace App\Http\Controllers;
use App\Product;
use App\Price;
use App\Currency;
use Illuminate\Support\Collection;
class CurrencyController extends Controller {

    public function import(){
        $response=file_get_contents("http://data.fixer.io/api/latest?access_key=e45636037247009c3e3f2c5bd02a26d4");
        $response2=file_get_contents("http://data.fixer.io/api/symbols?access_key=e45636037247009c3e3f2c5bd02a26d4");
        $data=json_decode($response);
        $data2=json_decode($response2);
        foreach ($data2->symbols as $key2 =>$val2){
                $currencies= new Currency ;
                $currencies->name=$val2;  
                $currencies->cod=$key2;
                foreach ($data->rates as $key =>$val){
                    if($key==$currencies->cod){
                        $currencies->rate=$val;
                    } 
                }    
                $currencies->save();              
            }
            // dump($data2);
        
        dump($currencies);

    }
}