<?php

namespace App\Http\Traits;

trait FixerEndpoint
{
    function getFixerData($fixer_endpoint = 'latest')
    {
        $fixer_access_key = 'e44ecbc27c4392d6d66fe57fa6e3b67b';
        $fixer_base_url = 'http://data.fixer.io/api/';
        $fixer_prefix_access_key = '?access_key=';

        $fixer_params = $fixer_endpoint . $fixer_prefix_access_key;
        $url = $fixer_base_url . $fixer_params . $fixer_access_key;

        $json_content = file_get_contents($url);
        $data = json_decode($json_content);

        return $data;
    }
}
