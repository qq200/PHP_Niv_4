<?php

namespace App\Http\Middleware;
use \App\{Cart, Price, Currency};

use Closure;

class CartMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        
        if($request->session()->get('cart_id')==null){
            $cart=Cart::create();
            $price=Price::create(['value'=> 0]);
            $price->currency()->associate(Currency::where('code', 'EUR')->first());
            $price->save();

            $cart->totalPrice()->save($price);
            $request->session()->put('cart_id', $cart->id);            
            
        }else{
            $cart=Cart::find($request->session()->get('cart_id'));
            
        }
        // dump($cart);

        if ($cart->exists()) {
            $cartItems = $cart->items;
            // $cartTotalItems = $cart->items->count();

            $cartTotalItems = 0;

            foreach ($cartItems as $item) {
                $cartTotalItems += $item->amount;
            }

            $cartTotalPrice = $cart->totalPrices->where('currency_id', '=', 93)->first()->value;
            $currencyCode = 'MDL';

            $cartItems = $cart->items;

            // dd($cartItems);

            $cartData = [
                'totalItems' => $cartTotalItems,
                'totalPrice' => $cartTotalPrice,
                'currencyCode' => $currencyCode,
                'cartItems' => $cartItems
            ];
        }
        View::share('cart', $cartData);
        return $next($request);

    }
}
