@extends('public.layout')

@isset($message)
@section('message')
<div class="alert alert-success mt-2" role="alert">
    {{ $message }}
</div>
@endsection
@endisset

@isset($products)
@section('content')
<div class="row">
    <div class="col-md-9">
        <h2>Catalog <small><i>{{ $products->total() }} products</i></small></h2>
    </div>
    <div class="col-md-3">
        <div class="d-flex justify-content-end">
            <div class="btn-group">
                <button type="button" class="btn btn-sm btn-light dropdown-toggle" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false">
                    Sort By
                </button>
                <div name="order_by" class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="{{ route('catalog') }}/price/expensive">Price Asc (expensive)</a>
                    <a class="dropdown-item" href="{{ route('catalog') }}/price/cheap">Price Desc (cheap)</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="{{ route('catalog') }}/date/old">Date Asc (old)</a>
                    <a class="dropdown-item" href="{{ route('catalog') }}/date/fresh">Date Desc (fresh)</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    @foreach ($products as $product)
    <div class="col-md-3 mt-2 mb-3">
        <a href="{{ $product->id }}">
            <img src="{{ $product->cover }}" class="rounded img-fluid mb-2" alt="{{ $product->name }}">
        </a>
        <h5 class="text-center"><a class="text-dark" href="{{ $product->id }}">{{ $product->name }}</a></h5>
        <p class="text-center">
            <b>{{ $product->prices->pluck('value')[0] }}</b> {{ $product->prices->first()->currency->code }}
        </p>
        <p class="text-center">
            <a class="btn btn-sm btn-warning" href="{{ route('home') }}/cart/add/{{ $product->id }}">Add to cart</a>
        </p>
    </div>
    @endforeach
</div>

@if ($products->count() > 0)
<div class="d-flex justify-content-center mb-5">
    {{ $products->links() }}
</div>
@endif
@endsection
@endisset
