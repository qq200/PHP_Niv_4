<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Home
Route::get('/', function () {
    return view('pages.home');
})->name('home');

// Cart
Route::prefix('cart')->group(function () {
    Route::get('/', 'CartController@index')->name('cart');
    Route::get('/view', 'CartController@view')->name('cart.view');
    Route::get('/add/{product_id}', 'CartController@add');
    Route::get('/add_one/{product_id}', 'CartController@add_one');
    Route::get('/remove_one/{product_id}', 'CartController@remove_one');
    Route::get('/empty', 'CartController@empty');
    Route::get('/remove/{cart_item_id}', 'CartController@remove');
});

// Catalog
Route::prefix('catalog')->group(function () {
    Route::get('/', 'CatalogController@index')->name('catalog');
    Route::get('/import', 'CatalogController@import');

    Route::get('/price/{sort}', 'CatalogController@indexPriceSort');
    Route::get('/date/{sort}', 'CatalogController@indexDateSort');
});

// Products
Route::prefix('products')->group(function () {
    Route::get('/', 'ProductController@index')->name('products');
    Route::get('/{{id}}', 'ProductController@view');
    Route::get('/test', 'ProductController@test');
});

// Subscribe
Route::prefix('subscribe')->group(function () {
    Route::get('/', 'ClientController@subscribeForm')->name('client.subscribe');
    Route::post('/', 'ClientController@subscribe');
});

// Test
Route::prefix('test')->group(function () {
    Route::get('/run', 'TestController@run');
});
