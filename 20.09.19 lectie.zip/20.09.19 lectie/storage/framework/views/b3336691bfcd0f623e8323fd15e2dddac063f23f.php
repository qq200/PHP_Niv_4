<?php $__env->startSection('content'); ?>

<?php if(isset($cart)): ?>
<div class="row">
    <div class="col-md-9">
        <h2>Your Cart</h2>
    </div>
</div>

<?php if($cart['totalItems'] > 0): ?>
<div class="row">
    <div class="col-md-12">
        <table class="table table-hover mb-5">
            <thead class="bg-dark text-white">
                <tr>
                    <th>#</th>
                    <th>Product</th>
                    <th class="text-center">Quantity</th>
                    <th class="text-center">Price</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 1;
                ?>
                <?php $__currentLoopData = $cart['cartItems']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td>
                        <img src="<?php echo e($item->product->cover); ?>" class="rounded" width="40" height="40">
                        <b><a href="<?php echo e(route('products')); ?>/<?php echo e($item->product->id); ?>"
                                class="text-dark"><?php echo e($item->product->name); ?></a></b>
                    </td>
                    <td class="text-center"><?php echo e($item->amount); ?></td>
                    <td class="text-center">
                        <?php if($item->amount > 1): ?>
                        <b><?php echo e($item->amount * $item->product->prices->first()->value); ?></b> <small><?php echo e($item->product->prices->where('currency_id', '=', 93)->first()->currency->code); ?></small><br>
                        <small><i><?php echo e($item->amount); ?> x
                                <?php echo e($item->product->prices->where('currency_id', '=', 93)->first()->value); ?> <?php echo e($item->product->prices->where('currency_id', '=', 93)->first()->currency->code); ?></i></small>
                        <?php else: ?>
                        <b><?php echo e($item->product->prices->first()->value); ?></b> <small><?php echo e($item->product->prices->where('currency_id', '=', 93)->first()->currency->code); ?></small>
                        <?php endif; ?>
                    </td>
                    <td class="text-center">
                        <div class="btn-group">
                            <button type="button" class="btn btn-sm btn-light dropdown-toggle" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">Actions</button>
                            <div name="order_by" class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('cart')); ?>/add_one/<?php echo e($item->id); ?>"><i class="fa fa-plus" aria-hidden="true"></i> Add item</a>
                                <a class="dropdown-item" href="<?php echo e(route('cart')); ?>/remove_one/<?php echo e($item->id); ?>"><i class="fa fa-minus" aria-hidden="true"></i> Remove item</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item text-danger" href="<?php echo e(route('cart')); ?>/remove/<?php echo e($item->id); ?>"><i class="fa fa-trash" aria-hidden="true"></i> Delete product</a>
                            </div>
                        </div>

                        
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td></td>
                    <td class="text-right"><b>TOTAL:</b></td>
                    <td class="text-center"><b><?php echo e($cart['totalItems']); ?> items</b></td>
                    <td class="text-center"><b><?php echo e($cart['totalPrice']); ?></b></td>
                    <td class="text-center"><a href="<?php echo e(route('cart')); ?>/empty" class="text-danger"><i
                                class="fa fa-trash" aria-hidden="true"></i>
                            Empty Cart</a></td>
                </tr>
            </tbody>
            
        </table>
    </div>
</div>
<?php else: ?>
Cart is empty.
<?php endif; ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\dev\php\php-4\ta_8\shop-v1\resources\views/public/cart.blade.php ENDPATH**/ ?>