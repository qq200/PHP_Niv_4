<?php $__env->startSection('cont'); ?>
<br>
    
    
            <li class="active"><a data-toggle="tab" href=" <?php echo e(route('cart')); ?>/checkout_reg " action="">Registration</a></li>
            <li><a data-toggle="tab" href=" <?php echo e(route('cart')); ?>/checkout_auth">Authentication</a></li>
            
            <li><a data-toggle="tab" href="#">Propose</a></li>
        
    <br>
    <?php echo $__env->yieldContent('cont-reg'); ?>
    <?php echo $__env->yieldContent('cont-auth'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('./public.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop-v1\resources\views///carts/checkout.blade.php ENDPATH**/ ?>