<?php
// dd($parentCategories);
?>



<?php $__env->startSection('import_link'); ?>
<a class="nav-link" href="<?php echo e(route('admin')); ?>/categories/import">Generate Categories</a>
<?php $__env->stopSection(); ?>

<?php if(isset($message)): ?>
<?php $__env->startSection('message'); ?>
<div class="alert alert-success mt-2" role="alert">
    <?php echo e($message); ?>

</div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php if(isset($parentCategories)): ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-9">
        <h4>List of categories <?php if($count_parentCategories > 0): ?>
            <small>(<?php echo e($count_items); ?> total categories | <?php echo e($count_parentCategories); ?> parent cat. /
                <?php echo e($count_subcategories); ?> subcat.)</small>
            <?php endif; ?></h4>
    </div>
    <div class="col-md-3">
        <?php if($count_parentCategories > 10): ?>
        <div class="d-flex justify-content-end">
            <div class="btn-group">
                <button type="button" class="btn btn-sm btn-light dropdown-toggle" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false">
                    <?php echo e($items_per_page); ?> items on page
                </button>
                <div name="per_page" class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <?php if($count_parentCategories > 10): ?>
                    <a class="dropdown-item" href="<?php echo e(route('admin')); ?>/categories/?per_page=10">10</a>
                    <?php endif; ?>
                    <?php if($count_parentCategories > 10): ?>
                    <a class="dropdown-item" href="<?php echo e(route('admin')); ?>/categories/?per_page=25">25</a>
                    <?php endif; ?>
                    <?php if($count_parentCategories > 25): ?>
                    <a class="dropdown-item" href="<?php echo e(route('admin')); ?>/categories/?per_page=50">50</a>
                    <?php endif; ?>
                    <?php if($count_parentCategories > 50): ?>
                    <a class="dropdown-item" href="<?php echo e(route('admin')); ?>/categories/?per_page=100">100</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php if($count_parentCategories > 0): ?>
<div class="row">
    <div class="col-md-12">
        <div class="accordion mb-5" id="accordionExample">
            <?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $subcategories = $category->children;
                    $count_subcategories = $subcategories->count();
                ?>

                <?php if($count_subcategories > 0): ?>
                <div class="card">
                    <div class="card-header bg-dark" id="headingOne">
                        <h2 class="mb-0">
                            <button class="btn btn-link text-white pl-1" type="button" data-toggle="collapse"
                                data-target="#collapse_id_<?php echo e($category->id); ?>" aria-expanded="false"
                                aria-controls="collapse_id_<?php echo e($category->id); ?>">
                                <?php echo e($category->name); ?> <small><i>(<?php echo e($count_subcategories); ?>)</i></small>
                            </button>
                        </h2>
                    </div>
                    <div id="collapse_id_<?php echo e($category->id); ?>" class="collapse show" aria-labelledby="headingOne"
                        data-parent="#accordionExample">
                        <div class="card-body ml-3">
                            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($subcategory->name); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="card">
                    <div class="card-header bg-secondary" id="headingOne">
                        <p class="pt-2 pl-1 mb-2 text-white">
                            <?php echo e($category->name); ?>

                        </p>
                    </div>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<?php if($count_parentCategories > 10): ?>

<div class="d-flex justify-content-center">
    <?php echo e($parentCategories->appends(['per_page' => $items_per_page])->links()); ?>

</div>
<?php endif; ?>
<?php else: ?>
<p>No items found!</p>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/shop-v1/resources/views/admin/categories.blade.php ENDPATH**/ ?>