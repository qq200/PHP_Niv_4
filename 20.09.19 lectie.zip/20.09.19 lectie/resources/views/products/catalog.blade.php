<h1>Prducts catalog</h1>
<hr>

@foreach ($products as $product)
    <div>{{ $product['name'] }}</div>
@endforeach