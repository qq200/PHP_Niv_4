@extends ('public.layout') 
{{-- trebuie de extins --}}
@section('content') 
{{-- {{ $cart->totalPrice->first()->value}}{{ $cart->totalPrice->first()->currency->name }} --}}
<h1> Afisarea produselor </h1>
<p style="text-align:right"><a href="/catalog/date/old">Sort of old date</a></p>
<p style="text-align:right"><a href="/catalog/date/fresh">Sort of fresh date</a></p>
    <table class="table">
        
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Product</th>
            <th scope="col">Price</th>
            <th scope="col">Created</th>
            
          </tr>
        </thead>
        <tbody>
          @foreach ($products as $product)
          <tr>
            <th scope="row">{{ $product->id }}</th>
            <td>{{ $product->name }}</td>
            <td>{{ $product->prices->first()->value }}</td>
            <td>{{ $product->created_at }}</td>           
          </tr>
          {{-- {{ dd($products->prices) }} --}}
          @endforeach           
        </tbody>
      </table>
  @csrf
 
  {{ $products->links() }}
  @endsection