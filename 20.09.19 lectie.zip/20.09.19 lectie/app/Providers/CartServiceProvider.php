<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Session;
use App\Cart;

class CartServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        
        // if(session('cart_id')==null){
        //     $cart=Cart::create();
        //     session(['cart_id'=>$cart->id]);
        //     dd($cart);
        //     dd(Session::all());
        // }else{
        //     $cart=Cart::fiind(session('cart_id'));
        //     dd($cart);
        // }
    }
}
