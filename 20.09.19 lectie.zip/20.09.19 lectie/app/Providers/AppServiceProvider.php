<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

use Illuminate\Support\Facades\View;

use App\Observers\CartObserver;

use App\{Cart, Price, Currency};

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    { 
        Cart::observe(CartObserver::class);
        // $cart = Cart::with('totalPrices')->first();
        // $cart = Cart::first();
        // dd($cart);

        // if ($cart->exists()) {
        //     $cartItems = $cart->items;
        //     // $cartTotalItems = $cart->items->count();

        //     $cartTotalItems = 0;

        //     foreach ($cartItems as $item) {
        //         $cartTotalItems += $item->amount;
        //     }

        //     $cartTotalPrice = $cart->totalPrices->where('currency_id', '=', 93)->first(); //->value
        //     $currencyCode = 'MDL';

        //     $cartItems = $cart->items;

        //     // dd($cartItems);

        //     $cartData = [
        //         'totalItems' => $cartTotalItems,
        //         'totalPrice' => $cartTotalPrice,
        //         'currencyCode' => $currencyCode,
        //         'cartItems' => $cartItems
        //     ];

        //     View::share('cart', $cartData);
        // }
    }
}
