@extends('./public.layout')

@section('cont')
        <ul class="nav nav-tabs">
            <li class="active"><a data-toggle="tab" href="#Registration" action="">Registration</a></li>
            <li><a data-toggle="tab" href="#Authentication ">Authentication</a></li>
            <li><a data-toggle="tab" href="#Propose">Propose</a></li>
        </ul> 
            <div class="tab-content">
                    <div id="Registration" class="tab-pane fade in active">
                            @include('clients.form-registration')
                            
                </div>
                <div id="Authentication" class="tab-pane fade">
                                @include('clients.form-authentication')
                           
                    </div>
                    <div id="Propose" class="tab-pane fade">
                       <h3>You can send mesage </h3>
                    </div>
                    
            </div>
        
    <br>
   
@endsection