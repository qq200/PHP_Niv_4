<form action="{{route('logout')}}" method="POST">
    @csrf
    <button >Logout</button>
{{-- <a href="{{route('logout')}}">Logout</a> --}}
</form>