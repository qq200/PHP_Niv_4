<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CartItem extends Model
{
    use SoftDeletes;

    protected $fillable = ['cart_id', 'product_id', 'amount'];

    public function cart()
    {
        return $this->belongsTo(\App\Cart::class);
    }

    public function product()
    {
        return $this->belongsTo(\App\Product::class);
    }

    public function itemPrices()
    {
        return $this->morphMany(\App\Price::class, 'priceable');
    }
}
