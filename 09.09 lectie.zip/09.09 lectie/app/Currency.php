<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Currency extends Model
{
    // configuram modelul
    // $fillable - permite setarea mai multor cimpuri simultan
    protected $fillable = ['code', 'name'];
    // protected $fillable = ['code', 'name', 'rate'];

    public function prices()
    {
        return $this->hasMany(\App\Price::class);
    }

    public function rates()
    {
        return $this->hasMany(\App\CurrencyRate::class);
    }
}
