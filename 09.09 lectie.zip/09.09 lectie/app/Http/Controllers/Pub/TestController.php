<?php

namespace App\Http\Controllers\Pub;
use App\Observers\CartObserver;

use Artisan;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\{Cart, Category, City, Client, ContactData, Country, Currency, CurrencyRate, Email, Phone, Price, Product, Social, SocialPlatform, Tag, User};

class TestController extends Controller
{
    public function run()
    {
        
        // Currencies
        $c = Currency::create([
                'code' => 'EUR',
                'name' => 'Euro',
            ]);
            
            $cr = CurrencyRate::create([
                    'rate' => 19.95,
                ]);
                
                $c = Currency::find(1);
                
                $c->rates()->save($cr);
                
                // Price 1 pentru Product
                $price_1 = Price::create([
                        'value' => '100'
                ]);
                
                $price_1->currency()->associate($c)->save();
                
                $prod = Product::create([
                        'name' => 'product'
                    ]);
                    
                $prod->prices()->save($price_1);
                        
                        // Pretul 2 pentru Cart
                        $price_2 = Price::create([
                                'value' => '200'
                        ]);
                        
                        $price_2->currency()->associate($c)->save();
                        $prod_2 = Product::create([
                            'name' => 'product2'
                        ]);
                        $prod_2->prices()->save($price_2);
                            
                            // $cart = Cart::create([]);
                            
                            // $cart->totalPrice()->save($price_2);
                            
                            // $cart->delete();
                            
                            // dd(Cart::find(1));
                            // dd(Cart::withTrashed()->where('id', 1)->get());
                            
                            // Cream entitatile
                            // $client = Client::create([
                                //     'fullname' => 'John Travolta'
                                // ]);
                                
                                // $contact_data = ContactData::create();
                                
                                // $country = Country::create([
                                    //     'name' => 'Moldova',
                                    //     'code' => 'MD'
                                    // ]);
                                    
                                    // $city_1 = City::create([
                                        //     'name' => 'Chisinau',
                                        //     'code' => 'C'
                                        // ]);
                                        
                                        // $city_2 = City::create([
                                            //     'name' => 'Balti',
                                            //     'code' => 'BL'
                                            // ]);
                                            
                                            // $phone_1 = Phone::create([
                                                //     'number' => '0699 99 999'
                                                // ]);
                                                
                                                // $phone_2 = Phone::create([
                                                    //     'number' => '0799 99 999'
                                                    // ]);
                                                    
                                                    // $email = Email::create([
                                                        //     'email' => 'email@email.md'
                                                        // ]);
                                                        
                                                        // $social_platform_1 = SocialPlatform::create([
                                                            //     'name' => 'facebook'
                                                            // ]);
                                                            
                                                            // $social_platform_2 = SocialPlatform::create([
                                                                //     'name' => 'linkedin'
                                                                // ]);
                                                                
                                                                // $social_1 = Social::create([
                                                                    //     'link' => 'facebook.com/fake_john_travolta'
                                                                    // ]);
                                                                    
                                                                    // $social_2 = Social::create([
                                                                        //     'link' => 'linkedin.com/fake_john_travolta'
                                                                        // ]);
                                                                        
                                                                        
                                                                        // // Legaturile entitatilor
                                                                        // $contact_data->phones()->save($phone_1);
                                                                        // $contact_data->phones()->save($phone_2);
                                                                        // $contact_data->country()->associate($country);
                                                                        // $contact_data->city()->associate($city_1);
                                                                        
                                                                        // $city_1->country()->associate($country)->save();
                                                                        // $city_2->country()->associate($country)->save();
                                                                        
                                                                        // // $social_platform_1->social()->associate($social_1);
                                                                        // // $social_platform_2->social()->associate($social_2);
                                                                        
                                                                        // $social_1->platform()->save($social_platform_1);
                                                                        // $social_2->platform()->save($social_platform_2);
                                                                        
                                                                        // // $social_platform_1->save();
                                                                        // // $social_platform_2->save();
                                                                        
                                                                        // $contact_data->email()->save($email);
                                                                        // $contact_data->socials()->save($social_1);
                                                                        // $contact_data->socials()->save($social_2);
                                                                        
                                                                        // $contact_data->client()->associate($client);
                                                                        // $contact_data->save();

                                                                        
                                                                        // ### Categories
                                                                        // Category::truncate();
                                                                        
                                                                        // $c1 = Category::create([
                                                                            //     'name' => 'Porumb',
                                                                            // ]);
                                                                            
                                                                            // $c2 = Category::create([
                                                                                //     'name' => 'Pop Corn',
                                                                                // ]);
                                                                                
                                                                                // $c3 = Category::create([
                                                                                    //     'name' => 'Pop Corn Sarat',
                                                                                    // ]);
                                                                                    
                                                                                    // $c1->children()->save($c2);
                                                                                    
                                                                                    // $c3->parent()->associate($c2);
                                                                                    // $c3->save();
                                                                                    
                                                                                    // $result = Category::where('name', 'Porumb')->get();
                                                                                    
                                                                                    // dd($result->first()->children);
                                                                                    
            // Artisan::call('migrate:refresh');
                
                // $cart = Cart::create([]);
               
                // dump(Cart::all());  //CartObserver
                // return 'Test run succesfull!';
            }
        }
                                                                                    