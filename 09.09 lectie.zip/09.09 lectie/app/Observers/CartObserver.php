<?php
namespace App\Observers;
use App\{Cart, Price, Currency};
class CartObserver
{
     /**
     * Handle the User "created" event.
     *
     * @param  \App\User  $user
     * @return void
     */
    public function created(Cart $cart)
    {
        $price_1=Price::create([
            'value' => 0,
             'discount' => true
        ]);
        $c = Currency::create([
            'code' => 'EUR',
            'name' => 'Euro',
        ]);
        
        $price_1->currency()->associate($c)->save();
        $cart->totalPrices()->save($price_1);
    }
    public function updated(User $user)
    {
        //
    }

    /**
     * Handle the User "deleted" event.
     *
     * @param  \App\User  $user
     * @return void
     */
    public function deleted(User $user)
    {
        //
    }
}
