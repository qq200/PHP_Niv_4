php artisan serve

app-> Clasele noi
app->Http->Controllers-> Controlerele care executa anumite functii in dependenta de cererea venita din ROUTES/WEB.PHP

resource->view-> cum se afiseaza o cerere sau alta pe ecran

routes->web.php arata la ce rura ce comanda se executa