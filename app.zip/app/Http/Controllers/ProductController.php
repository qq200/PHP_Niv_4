<?php

namespace App\Http\Controllers;

class ProductController extends Controller {

    public function index(){
        //imbracam arrayul intro colectie obiect tip Collection

        $products=collect([
            ['name'=> 'Product 1', 'price'=>1000],
            ['name'=> 'Product 2', 'price'=>2000],
            ['name'=> 'Product 3', 'price'=>3000]
        ])
        ->sortByDesc('price')
        ->where('price', '>', 1000);
        // dump($products);
        // dd($products); //pentru testare

        return view("products.catalog", ['products'=>$products]);
    }
}