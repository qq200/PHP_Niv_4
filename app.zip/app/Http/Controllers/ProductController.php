<?php

namespace App\Http\Controllers;
use App\Product;
use App\Price;
use Illuminate\Support\Collection;
class ProductController extends Controller {

    public function index(){
        //imbracam arrayul intro colectie obiect tip Collection

        $products=collect([
            ['name'=> 'Product 1', 'price'=>1000],
            ['name'=> 'Product 2', 'price'=>2000],
            ['name'=> 'Product 3', 'price'=>3000]
        ])
        ->sortByDesc('price')
        ->where('price', '>', 1000);
        // dump($products);
        // dd($products); //pentru testare

        return view("products/catalog", ['products'=>$products]);
    }
    public function test(){
        
        $products=collect([
        [ 'p'=>new Product('Product-1', collect([['im'=>'https://picsum.photos/id/100/600/300'],['im'=>'https://picsum.photos/id/99/600/300'],['im'=>'https://picsum.photos/id/98/600/300']]), new Price(1000, 'MDL'))], 
        [ 'p'=>new Product('Product-2', collect([['im'=>'https://picsum.photos/id/201/600/300'], ['im'=>'https://picsum.photos/id/101/600/300']]), new Price(2000, 'MDL'))],
        [ 'p'=>new Product('Product-3',collect([['im'=>'https://picsum.photos/id/202/600/300'], ['im'=>'https://picsum.photos/id/102/600/300']]), new Price(3000, 'MDL'))],
        [ 'p'=>new Product('Product-4',collect([['im'=>'https://picsum.photos/id/203/600/300'], ['im'=>'https://picsum.photos/id/103/600/300']]), new Price(4000, 'MDL'))],
        [ 'p'=>new Product('Product-5',collect([['im'=>'https://picsum.photos/id/204/600/300'], ['im'=>'https://picsum.photos/id/104/600/300']]), new Price(5000, 'MDL'))],
        ]);
         return view("products/test", ['products'=>$products]);
    }
}