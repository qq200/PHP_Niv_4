<?php

namespace App;

class Product {
    private $name ;
    private $images;
    private $price; 

    public function __construct($name, $image,
    $price){
        $this->name= $name;
        $this->images[]= $image;
        $this->price=$price;
    }
    public function __set($propr_name, $propr_value){
        
        if($propr_name=="name" ){
            if(is_string($propr_value)){
                $propr_value=trim($propr_value);  //daca de aplica proprietaea name se curata spatiile goale
            }else{
                die ("ERROR, {$propr_name} must be string");
            }
        }
        if($propr_name=="images" ){
            if(is_array($propr_value)){
                    $propr_value=trim($propr_value);  //daca de aplica proprietaea name se curata spatiile goale
            }else{
                    die ("ERROR, {$propr_name} must be array");
            }
        }
        if($propr_name=="price" ){            
            // if(strtolower(get_class($propr_value)) == 'comerce\models\price' ){
            // } else{
            //     die ("ERROR, {$propr_name} must be object");
            // }           
        }
        $this->$propr_name=$propr_value;
    }

    public function __get($propr_name){
        return $this->$propr_name;
    }

    public function addImage($url){
        $this->images[]= $url;
        $uniq = array_unique($this->image);
        $this->images=$uniq;
        return $this->images;
    }

    public function getMainImage(){
        
        return $this->images[0];
    }


}


?>