<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    //
    protected $fillable= ['name'];
    public function parent(){
        return $this->belongsTo(\App\Category::class, 'category_id'); //apartine  // din cauza ca functia nu se numeste category trebuie de indicat prin care coloana trebuie de facut legatura ->category_id(el cauta parent_id)
    }
    public function cildren(){
        return $this->hasMany(\App\Country::class); // are mai multe
    }
}
