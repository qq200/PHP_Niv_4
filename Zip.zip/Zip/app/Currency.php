<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Currency extends Model
{
    //configuram modelul pe toate componentele
    protected $fillable= ['name', 'cod'];
    public function rates()
    {
        return $this->hasMany(\App\CurrencyRate::class);
    }
    public function price()
    {
        return $this->hasOne(\App\Price::class);
    }
}
 