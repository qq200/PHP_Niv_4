<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Email extends Model
{
    //
    protected $fillable= ['email', 'subscribed'];
    public function contacts(){
        return $this->belongsTo(\App\Client::class);
    }
}
