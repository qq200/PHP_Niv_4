<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContactData extends Model
{

    protected $table='contact_datas';


    //
    public function phones(){
        return $this->hasMany(\App\Phone::class);// din model
    }
    public function city(){
        return $this->belongsTo(\App\City::class);// din model
    }
    public function country(){
        return $this->belongsTo(\App\Country::class);// din model
    }
    public function client(){
        return $this->belongsTo(\App\Client::class);// din model
    }


}
